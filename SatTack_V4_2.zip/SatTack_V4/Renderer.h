// Renderer Header

#pragma once
#include <vector>
#include <string>

using namespace std;
struct Sample { // each sample
    double lat;
    double lon;
};

class Renderer {
public:
    Renderer(int width, int height); // load blank RGB canvas (not used anymore)
    bool loadMap(const string& path); // load worldmap.png
    void addSample(double lat, double lon); // add sample of sat position
    void saveBMP(const string& filename); // save final img as bitmap
    void addGroundStation(double lat, double lon, const string& label = "");
    void drawTrack(int radius = 3); // pixel radius can be changed

private:
    int width_, height_; // image dims
    vector<unsigned char> pixels_; // raw rgb pixel buffer
    vector<Sample> samples_; // list of samples to plo

    void putPixel(int x, int y, unsigned char r, unsigned char g, unsigned char b); // write each pixel into buffer
    pair<int,int> projectLatLon(double lat, double lon) const; // convert lat lon to pixel coords
    struct GroundStation { // ground station marker for map
        double lat, lon;
        string label; // optional label
    };
    vector<GroundStation> stations_; // can add more stations to this

    void drawGroundStations(); // draw groundstation
};