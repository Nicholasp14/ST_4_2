// SatTrack Iteration: 4 | Nicholas Pagano | AERSP424 Project

//    :'######:::::'###::::'########:'########:'########:::::'###:::::'######::'##:::'##:
//    '##... ##:::'## ##:::... ##..::... ##..:: ##.... ##:::'## ##:::'##... ##: ##::'##::
//     ##:::..:::'##:. ##::::: ##::::::: ##:::: ##:::: ##::'##:. ##:: ##:::..:: ##:'##:::
//    . ######::'##:::. ##:::: ##::::::: ##:::: ########::'##:::. ##: ##::::::: #####::::
//    :..... ##: #########:::: ##::::::: ##:::: ##.. ##::: #########: ##::::::: ##. ##:::
//    '##::: ##: ##.... ##:::: ##::::::: ##:::: ##::. ##:: ##.... ##: ##::: ##: ##:. ##::
//    . ######:: ##:::: ##:::: ##::::::: ##:::: ##:::. ##: ##:::: ##:. ######:: ##::. ##:
//    :......:::..:::::..:::::..::::::::..:::::..:::::..::..:::::..:::......:::..::::..::

// This code takes in 3 main user defined parameters:
// 1) User defined lat, long, and alt: see variables with prefix "obs_" in MAIN and change
// 2) User defined frequency (this should be the downlink frequency of your Sat): see "radial_velocity_and_doppler" call
// ... in Main. Note that this is assumed to be in Hz
// 3) User provided Two Line Element (TLE): This will be asked for in the terminal, simply print there
// With these parameters the code outputs propagated time, latitude, longitude, and altitude for the spacecrafts
//... position based on the sample duration (default 90mins), and in 10 second time steps
// It also prints out azimuth and elevation (in deg) which can be passed to an antenna rotator for tracking
// Finally, the spacecrafts radial velocity and the Doppler Corrected Frequency are also printed at each timestep
// After the code has run for the full sample time, the spacecrafts position at each time step is plotted, along with
//... the GroundStation location to a file called groundtrack.bmp found in SatTrackV4 -> cmake-build-debug -> out
// See the README file for detailed instructions for running this code on both MAC and Windows

// Novel Header Files created for this project
#include "Tle.h"
#include "Satellite.h"
#include "Renderer.h" // Note that the third party header "stb_image" is wrapped into this header and its source file
#include "Pointing.h"

// Some Standard Library Headers...
#include <iostream>
#include <string>
#include <vector>
#include <tuple> // Standard Library header that allows for one to create a collection of values with diff types
#include <filesystem> // Enables interaction with file paths and more (used for loading / writing GroundTrack bitmap)
#include <iomanip> // Standard Library header for manipulating i/o (mostly used for formatting, like decimal precision)
#include <cmath> // needed for the if statement check for NaN values in Sampling loop

using namespace std;
using LatLon = tuple<double,double,double>;

// Trim whitespace
static inline string trim(const string& s) {
    auto l = s.find_first_not_of(" \t\r\n"); // scan from left till finds non-whitespace character
    if (l == std::string::npos) return ""; // return empty string if its all whitespace
    auto r = s.find_last_not_of(" \t\r\n"); // scan from right
    return s.substr(l, r - l + 1); // extract substring between first and last non-whitespace characters
}

int main() {
    cout << "Paste a two-line (TLE) Below:\n";
    vector<string> lines;
    string line;
    while (getline(cin, line)) { // getline preserves the line in the case of spaces
        line = trim(line); // triming whitespace implemented
        if (line.empty()) continue; // ignore blank lines from coying TLE over from somwhere
        lines.push_back(line);
        if (lines.size() >= 2) break; // stop after two valid lines
    }

    if (lines.size() < 2) { // throw error if pasted info doesn't match TLE sizing
        cerr << "Error: expected two non-empty TLE lines but got " << lines.size() << ".\n";
        return 1;
    }

    auto maybeTle = Tle::fromLines(lines[0], lines[1]); // calls on fromLines function found in Tle source
    if (!maybeTle) { // throw error if function fails
        cerr << "Error: failed to parse TLE. Check format and try again.\n";
        return 2;
    }
    Tle  tle = *maybeTle;

    // Construct satellite from parsed TLE
    Satellite sat(tle);

    // User Defined Lat,Long, and Altitude for GroundStation plotting and pointing
    double obs_lat_deg  = 40.7934;
    double obs_lon_deg  = -77.8600;
    double obs_alt_km  = 0.351;
    Vec3 obs_ecef = ecef_from_geodetic(obs_lat_deg, obs_lon_deg, obs_alt_km); // build vect to convert to ECEF

    // Sampling parameters
    const int duration_s = 90 * 60; // 90 minutes
    const int step_s = 10;  // 10 second timestep

    vector<LatLon> samples;
    samples.reserve(duration_s / step_s + 1);

    cout << "t(s), lat(deg), lon(deg),  alt(km),     az(deg),     el(deg),   v_rad (km/s),   f_corr(Hz)\n";
    cout << fixed << setprecision(6);
    for (int t = 0; t <= duration_s; t += step_s) {
        // Get satellite geodetic (lat, lon, alt) from propagator
        auto [lat, lon, alt] = sat.propagate_seconds(static_cast<double>(t));
        // Convert satellite geodetic to ECEF
        Vec3 sat_ecef = ecef_from_geodetic(lat, lon, alt);
        // Relative vector and ENU
        array<double,3> enu = enu_from_ecef(sat_ecef, obs_ecef, obs_lat_deg, obs_lon_deg);
        // Azimuth and elevation
        auto [az_deg, el_deg] = az_el_from_enu(enu);
        // Radial veloity for Doppler using finite difference approximation
        double dt = 1.0; // seconds
        auto [lat_f, lon_f, alt_f] = sat.propagate_seconds(static_cast<double>(t + dt));
        Vec3 sat_ecef_f = ecef_from_geodetic(lat_f, lon_f, alt_f);
        Vec3 v_sat = { (sat_ecef_f[0] - sat_ecef[0]) / dt,
                       (sat_ecef_f[1] - sat_ecef[1]) / dt,
                       (sat_ecef_f[2] - sat_ecef[2]) / dt };
        // Radial velocity and doppler for given frequency (Hz)
        Vec3 r_rel = { sat_ecef[0] - obs_ecef[0], sat_ecef[1] - obs_ecef[1], sat_ecef[2] - obs_ecef[2] };
        auto [radial_v, f_obs] = radial_velocity_and_doppler(r_rel, v_sat, 145825000.0); // Don't forget its in Hz

        if (!isfinite(lat) || !isfinite(lon) || !isfinite(alt)) { // Needed because code wouldn't compile due to NaN entries for some samples
            cerr << "Skipping invalid sample at t=" << t << "\n"; // Skips a sample if result is NaN
            continue;
        }
        samples.emplace_back(lat, lon, alt);
        // Print results at each timestep
        cout << t << ", " << lat << ", " << lon << ", " << alt
                   << ", " << az_deg << ", " << el_deg
                   << ", " << radial_v << ", " << f_obs << "\n";
    }
    // Ensure output directory exists
    filesystem::create_directories("out");
    // Define sizing
    Renderer renderer(2048, 1024);
    // Load  map first
    renderer.loadMap("worldmap.png");
    // Draw samples
    for (auto& s : samples) {
        double lat = std::get<0>(s);
        double lon = std::get<1>(s);
        renderer.addSample(lat, lon);
    }
    // Add GS from User-Defined Lat / Lon
    renderer.addGroundStation(obs_lat_deg, obs_lon_deg, "PSU");
    //Save Bit Map | Can be changed later for jpg or png
    renderer.saveBMP("out/groundtrack.bmp");

    // stop .exe from closing
    system("pause");

    return 0;
}