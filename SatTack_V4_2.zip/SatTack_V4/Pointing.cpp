// Pointing source file

#include "Pointing.h"
#include <cmath>

using namespace std;

static constexpr double a_wgs84 = 6378.137;      // equatorial radius km
static constexpr double f_wgs84 = 1.0 / 298.257223563; // flattening
static constexpr double b_wgs84 = a_wgs84 * (1.0 - f_wgs84); // polar radis
static constexpr double e2 = 1.0 - (b_wgs84*b_wgs84)/(a_wgs84*a_wgs84); // ecentricity squared
static constexpr double c_km_s = 299792.458; // speed of light km/s

using std::sin;
using std::cos;
using std::sqrt;

Vec3 ecef_from_geodetic(double lat_deg, double lon_deg, double alt_km) { // take geodetic and xform to ecef frame
    double lat = lat_deg * M_PI / 180.0; // 2 radians
    double lon = lon_deg * M_PI / 180.0; // 2 radians
    double sinlat = sin(lat); // compute sin lat
    double coslat = cos(lat); // compute cos lat
    double N = a_wgs84 / sqrt(1.0 - e2 * sinlat * sinlat); // compute radius of curvature
    double x = (N + alt_km) * coslat * cos(lon); // xform x component
    double y = (N + alt_km) * coslat * sin(lon); // xform y component
    double z = (N * (1.0 - e2) + alt_km) * sinlat; // xform z component
    return Vec3{ x, y, z }; // return ecef vector
}

array<double,3> enu_from_ecef(const Vec3& r_sat_ecef, const Vec3& r_obs_ecef, double lat_obs_deg, double lon_obs_deg) { // take ecef and xform to enu frame for pointing
    Vec3 r_rel{ r_sat_ecef[0] - r_obs_ecef[0], // r_rel = sat - obs
                r_sat_ecef[1] - r_obs_ecef[1],
                r_sat_ecef[2] - r_obs_ecef[2] };

    double lat = lat_obs_deg * M_PI / 180.0; // 2 radians
    double lon = lon_obs_deg * M_PI / 180.0; // 2 radians
    double sinlat = sin(lat), coslat = cos(lat); // compute sin / cos of lat
    double sinlon = sin(lon), coslon = cos(lon); // compute sin / cos of lon

    // East
    double E = -sinlon * r_rel[0] + coslon * r_rel[1];
    // North
    double N = -sinlat * coslon * r_rel[0] - sinlat * sinlon * r_rel[1] + coslat * r_rel[2];
    // Up
    double U =  coslat * coslon * r_rel[0] + coslat * sinlon * r_rel[1] + sinlat * r_rel[2];

    return {E, N, U};
}

pair<double,double> az_el_from_enu(const array<double,3>& enu) { // generate az el pointing instructions from enu reference frame
    double E = enu[0], N = enu[1], U = enu[2];
    double az = atan2(E, N) * 180.0 / M_PI;
    if (az < 0) az += 360.0; // quadrant check
    double el = atan2(U, sqrt(E*E + N*N)) * 180.0 / M_PI;
    return {az, el};
}

static double dot3(const Vec3& a, const Vec3& b) { // compute dot prod
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}
static double norm3(const Vec3& a) { // normalize
    return sqrt(dot3(a,a));
}

pair<double,double> radial_velocity_and_doppler(const Vec3& r_rel, const Vec3& v_sat_ecef, double tx_freq_hz) { //  compute radial velocity for doppler
    double r_norm = norm3(r_rel);
    if (r_norm <= 0.0) return {0.0, tx_freq_hz}; // radial velocity  positive if moving away
    double vr = dot3(v_sat_ecef, r_rel) / r_norm;
    double f_obs = tx_freq_hz * (c_km_s / (c_km_s + vr)); // f_obs = f_tx * c / (c + vr) (approximately)
    return {vr, f_obs};
}

tuple<double,double,double> ecef_to_geodetic(const Vec3& r) { // Go back to geodetic for groundtrack maping
    const double a = 6378.137;                 // equitorial radius km (didnt have to redefine these)
    const double f = 1.0 / 298.257223563;      // flattening
    const double e2 = f * (2 - f);             // eccentricity squared

    double x = r[0], y = r[1], z = r[2];
    double lon = atan2(y, x);

    double rxy = sqrt(x*x + y*y);
    double lat = atan2(z, rxy * (1 - e2));     // initial guess

    for (int i = 0; i < 10; ++i) {
        double sinlat = sin(lat);
        double N = a / sqrt(1 - e2 * sinlat * sinlat);
        double alt = rxy / cos(lat) - N;
        double lat_new = atan2(z, rxy * (1 - e2 * N / (N + alt)));
        if (fabs(lat_new - lat) < 1e-12) break;
        lat = lat_new;
    }

    double sinlat = sin(lat);
    double N = a / sqrt(1 - e2 * sinlat * sinlat);
    double alt = rxy / cos(lat) - N;

    return { lat * 180.0/M_PI, lon * 180.0/M_PI, alt }; // go back to degrees
}