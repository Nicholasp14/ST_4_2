// Tle Source

#include "Tle.h"
#include <fstream> // Standard Library header for file handling
#include <sstream> // Standard Library header that allows
#include <iomanip> // Header used mostly for formatting numbers
#include <algorithm> // Standard Library header used for find if, remove if, etc.
#include <cctype> // Header used to classify characters

using namespace std;

static inline string trim(const string& s) { // same whitespace triming helper
    auto l = s.find_first_not_of(" \t\r\n");
    if (l == string::npos) return "";
    auto r = s.find_last_not_of(" \t\r\n");
    return s.substr(l, r - l + 1);
}

bool Tle::isValid() const {
    return !line1.empty() && !line2.empty() && mean_motion_rev_per_day > 0.0; // check if both lines are valid and mean motion is not negative (must be error otherwise)
}

optional<Tle> Tle::fromLines(const string& l1, const string& l2) {
    Tle t;
    t.line1 = l1;
    t.line2 = l2;

// inclination: cols 9-16 (8..15)
// RAAN: cols 18-25 (17..24)
// eccentricity: cols 27-33 (26..32) Note: NO DECIMAL POINT
// arg of perigee: cols 35-42 (34..41)
// mean anomaly: cols 44-51 (43..50)
// mean motion: cols 53-63 (52..62)

    auto safe_sub = [&](const string &s, int a, int b)->string { // helper to get even if the line is shorter than expected
        if (a < 0) a = 0;
        if (a >= (int)s.size()) return "";
        int len = b - a + 1;
        if (a + len > (int)s.size()) len = s.size() - a;
        return s.substr(a, len);
    };

    try { // go to locations prescribed above and get values
        string incl_s = trim(safe_sub(l2, 8, 15));
        string raan_s = trim(safe_sub(l2, 17, 24));
        string ecc_s = trim(safe_sub(l2, 26, 32));
        string argp_s = trim(safe_sub(l2, 34, 41));
        string m_s = trim(safe_sub(l2, 43, 50));
        string n_s = trim(safe_sub(l2, 52, 62));


        // check if empty, if not, assign values
        if (!incl_s.empty()) t.inclination_deg = stod(incl_s);
        if (!raan_s.empty()) t.raan_deg = stod(raan_s);
        if (!ecc_s.empty()) {
            string digits; // ensure only digits for ecc
            for (char c : ecc_s) if (isdigit((unsigned char)c)) digits.push_back(c);
            if (!digits.empty()) {
                t.eccentricity = stod("0." + digits);
            }
        }
        if (!argp_s.empty()) t.arg_perigee_deg =stod(argp_s);
        if (!m_s.empty()) t.mean_anomaly_deg = stod(m_s);
        if (!n_s.empty()) t.mean_motion_rev_per_day = stod(n_s);

        // parse epoch from line1 and format to YYDDD.DDDDDDDD
        string epoch_s = trim(safe_sub(l1, 18, 31));
        if (!epoch_s.empty()) {
            // split first two chars year, rest day-of-year
            if (epoch_s.size() >= 3) {
                string yy = epoch_s.substr(0,2);
                string doy = epoch_s.substr(2);
                t.epoch_year = stoi(yy);
                t.epoch_day_of_year = stod(doy);
            }
        }
    } catch (...) {
        return nullopt;
    }

    if (!t.isValid()) return nullopt;
    return t;
}