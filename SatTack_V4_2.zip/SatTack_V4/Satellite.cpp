// Satellite Source file

#include "Satellite.h"
#include <cmath>
#include <iostream>

using namespace std;

static inline double deg2rad(double d) { return d * M_PI / 180.0; }
static inline double rad2deg(double r) { return r * 180.0 / M_PI; }

Satellite::Satellite(const Tle& tle) { // take elements from TLE and assign to variables
    i_rad = deg2rad(tle.inclination_deg);
    raan_rad = deg2rad(tle.raan_deg);
    argp_rad = deg2rad(tle.arg_perigee_deg);
    M0_rad = deg2rad(tle.mean_anomaly_deg);
    ecc = tle.eccentricity;
    mean_motion_rad_per_s = tle.mean_motion_rev_per_day * 2.0 * M_PI / 86400.0; // mean motion: rev/day -> rad/s

    // compute semi-major axis from n^2 a^3 = mu
    if (mean_motion_rad_per_s > 0.0) {
        a_km = cbrt(mu / (mean_motion_rad_per_s * mean_motion_rad_per_s));
    } else {
        a_km = 0.0;
    }
}

// Propagate using simple Keplerian motion, ie solving Keplers eqn approximately (first order approx)
tuple<double,double,double> Satellite::propagate_seconds(double sec) const {
    // mean anomaly at time t
    double M = M0_rad + mean_motion_rad_per_s * sec;
    // normalize
    M = fmod(M, 2.0*M_PI);
    if (M < 0) M += 2.0*M_PI;
    // approximate eccentric anomaly E for small e
    double E = M + ecc * sin(M);
    // position in orbital plane km
    double cosE = cos(E);
    double sinE = sin(E);
    double r = a_km * (1.0 - ecc * cosE); // radius
    double x_orb = a_km * (cosE - ecc);
    double y_orb = a_km * sqrt(max(0.0, 1.0 - ecc*ecc)) * sinE;

    // rotate from orbital plane to ECI:
    double cos_omega = cos(argp_rad);
    double sin_omega = sin(argp_rad);
    double cos_raan = cos(raan_rad);
    double sin_raan = sin(raan_rad);
    double cos_i = cos(i_rad);
    double sin_i = sin(i_rad);

    // compute rotation matrix components using rotation sequence
    double r11 = cos_raan * cos_omega - sin_raan * sin_omega * cos_i;
    double r12 = -cos_raan * sin_omega - sin_raan * cos_omega * cos_i;
    double r13 = sin_raan * sin_i;

    double r21 = sin_raan * cos_omega + cos_raan * sin_omega * cos_i;
    double r22 = -sin_raan * sin_omega + cos_raan * cos_omega * cos_i;
    double r23 = -cos_raan * sin_i;

    double r31 = sin_omega * sin_i;
    double r32 = cos_omega * sin_i;
    double r33 = cos_i;

    double x_eci = r11 * x_orb + r12 * y_orb;
    double y_eci = r21 * x_orb + r22 * y_orb;
    double z_eci = r31 * x_orb + r32 * y_orb;

    // convert ECI to approximate geodetic lat and long / rotate frame by theta
    double theta = earth_rotation_rate * sec;
    double cos_th = std::cos(theta);
    double sin_th = std::sin(theta);

    double x_ecef =  cos_th * x_eci + sin_th * y_eci;
    double y_ecef = -sin_th * x_eci + cos_th * y_eci;
    double z_ecef = z_eci;

    double r_xy = std::sqrt(x_ecef*x_ecef + y_ecef*y_ecef);
    double lat_rad = std::atan2(z_ecef, r_xy); // geocentric lat
    double lon_rad = std::atan2(y_ecef, x_ecef); // gecentric lon

    double lat_deg = rad2deg(lat_rad);
    double lon_deg = rad2deg(lon_rad);

    // normalize lon
    if (lon_deg > 180.0) lon_deg -= 360.0;
    if (lon_deg <= -180.0) lon_deg += 360.0;

    double alt_km = r - 6378.137; // approximate altitude above mean Earth radius

    return {lat_deg, lon_deg, alt_km};
}