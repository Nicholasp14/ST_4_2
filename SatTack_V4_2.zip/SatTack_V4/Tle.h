// Tle Header

#pragma once
#include <string>
#include <optional>

using namespace std;

struct Tle {
    string line1;
    string line2;

    // Parsed COEs from line 2 of TLE
    double inclination_deg = 0.0; // i
    double raan_deg = 0.0;  // Omega cap
    double eccentricity = 0.0; // e
    double arg_perigee_deg = 0.0; // omega
    double mean_anomaly_deg = 0.0; // M0
    double mean_motion_rev_per_day = 0.0; // n (rev/day)

    // epoch in TLE format (YYDDD.DDDDD)
    double epoch_day_of_year = 0.0;
    int epoch_year = 0; // two-digit year

    bool isValid() const;
    static std::optional<Tle> fromFile(const std::string& path);
    static std::optional<Tle> fromLines(const std::string& l1, const std::string& l2);
};