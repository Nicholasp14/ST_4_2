// Pointing Header

#pragma once
#include <array>
#include <tuple>

using namespace std;

// ECEF vector in km
using Vec3 = std::array<double,3>;

// Convert geodetic (deg,deg,km) to ECEF (km)
Vec3 ecef_from_geodetic(double lat_deg, double lon_deg, double alt_km);

// Convert satellite ECEF and observer geodetic to ENU (east,north,up) vector
array<double,3> enu_from_ecef(const Vec3& r_sat_ecef, const Vec3& r_obs_ecef, double lat_obs_deg, double lon_obs_deg);

// Compute azimuth (deg) and elevation (deg) from ENU
pair<double,double> az_el_from_enu(const array<double,3>& enu);

// Compute radial velocity (km/s) and Doppler-shifted frequency
pair<double,double> radial_velocity_and_doppler(const Vec3& r_rel, const Vec3& v_sat_ecef, double tx_freq_hz);

// Go back to geodetic for plotting
tuple<double,double,double> ecef_to_geodetic(const Vec3& r);