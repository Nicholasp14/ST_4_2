// Satellite Header

#pragma once
#include "Tle.h"
#include <tuple>

using namespace std;

class Satellite {
public:
    explicit Satellite(const Tle& tle);

    // seconds since TLE epoch
    tuple<double,double,double> propagate_seconds(double sec) const;

private:
    // classical elements (radians)
    double i_rad;
    double raan_rad;
    double argp_rad;
    double M0_rad;
    double mean_motion_rad_per_s; // mean motion
    double ecc;
    double a_km; // semi-major axis computed from mean motion km

    // constants
    static constexpr double mu = 398600.4418; // Earth gravitational parameter m^3/s^2
    static constexpr double earth_rotation_rate = 7.2921150e-5; // rad/s
};