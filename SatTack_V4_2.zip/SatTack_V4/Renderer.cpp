// Renderer Source
// Note that the image may be changed, and is found in cmake-build-debug
// It does, however, have to be equirectangular to correctly draw

#include "Renderer.h"
#include <cmath>
#include <fstream>
#include <iostream>
#define STB_IMAGE_IMPLEMENTATION
#include <cstring>
#include "stb_image.h"

Renderer::Renderer(int width, int height) // construct blank rgb pixel buffer set to black
    : width_(width), height_(height),
      pixels_(width * height * 3, 0)
{}

bool Renderer::loadMap(const std::string& path) { // load map and copy pixels directly to buffer
    int w, h, n;
    unsigned char* data = stbi_load(path.c_str(), &w, &h, &n, 3);  // only saved to 3 channels (rgb)
    if (!data) {
        std::cerr << "Failed to load map: " << path << "\n";
        return false;
    }

    if (w != width_ || h != height_) { // check map size
        std::cerr << "Map size mismatch: expected "
                  << width_ << "x" << height_
                  << " got " << w << "x" << h << "\n";
        stbi_image_free(data);
        return false;
    }

    std::memcpy(pixels_.data(), data, width_ * height_ * 3); // Copy RGB map directly

    stbi_image_free(data);
    return true;
}

void Renderer::addSample(double lat, double lon) { // add groundtrack sample
    samples_.push_back({lat, lon});
}

void Renderer::putPixel(int x, int y, unsigned char r, unsigned char g, unsigned char b) { // write each pixel into buffer
    if (x < 0 || x >= width_ || y < 0 || y >= height_) return;
    int idx = (y * width_ + x) * 3;
    pixels_[idx + 0] = r;
    pixels_[idx + 1] = g;
    pixels_[idx + 2] = b;
}

std::pair<int,int> Renderer::projectLatLon(double lat, double lon) const { // convert to pixel coords
    double x = (lon + 180.0) / 360.0 * width_;
    double y = (90.0 - lat) / 180.0 * height_;
    return { (int)x, (int)y };
}

void Renderer::addGroundStation(double lat, double lon, const std::string& label) {
    stations_.push_back({lat, lon, label});
}

void Renderer::drawGroundStations() { // more ground stations can be added
    for (auto& gs : stations_) {
        auto [cx, cy] = projectLatLon(gs.lat, gs.lon);

        int armLen = 8;  // Crosshair arms
        for (int i = -armLen; i <= armLen; ++i) {
            putPixel(cx + i, cy,     255, 0, 0);  // horizontal
            putPixel(cx,     cy + i, 255, 0, 0);  // vertical
        }

        for (int dy = -2; dy <= 2; ++dy) // Filled center square
            for (int dx = -2; dx <= 2; ++dx)
                putPixel(cx + dx, cy + dy, 255, 255, 0);
    }
}

void Renderer::drawTrack(int radius) { // draw track from samples with each being a square appx of a circle with a given radius
    for (auto& s : samples_) {
        auto [cx, cy] = projectLatLon(s.lat, s.lon);
        for (int dy = -radius; dy <= radius; ++dy)
            for (int dx = -radius; dx <= radius; ++dx)
                putPixel(cx + dx, cy + dy, 255, 0, 0);
    }
}

// Save the final image as a 24‑bit bitmap
// BMP format requires:
// 54‑byte header
// bottom‑up row order
// BGR pixel order (not RGB)

void Renderer::saveBMP(const std::string& filename) {
    drawTrack();
    drawGroundStations();
    std::ofstream f(filename, std::ios::binary);
    if (!f) {
        std::cerr << "Failed to open output file: " << filename << "\n";
        return;
    }

    int fileSize = 54 + width_ * height_ * 3;

    unsigned char header[54] = {
        'B','M',
        (unsigned char)(fileSize      ),
        (unsigned char)(fileSize >>  8),
        (unsigned char)(fileSize >> 16),
        (unsigned char)(fileSize >> 24),
        0,0,0,0,
        54,0,0,0,
        40,0,0,0,
        (unsigned char)(width_      ),
        (unsigned char)(width_ >>  8),
        (unsigned char)(width_ >> 16),
        (unsigned char)(width_ >> 24),
        (unsigned char)(height_      ),
        (unsigned char)(height_ >>  8),
        (unsigned char)(height_ >> 16),
        (unsigned char)(height_ >> 24),
        1,0,
        24,0,
        0,0,0,0,
        0,0,0,0,
        0,0,0,0,
        0,0,0,0,
        0,0,0,0,
        0,0,0,0
    };

    f.write((char*)header, 54);

    // BMP rows are bottom-up, and BMP pixel format is BGR / HUGE PROBLEM B4 I REALIZED THEY NEEDED TO BE FLIPPED
    for (int y = height_ - 1; y >= 0; --y) {
        for (int x = 0; x < width_; ++x) {
            int idx = (y * width_ + x) * 3;
            unsigned char bgr[3] = {
                pixels_[idx + 2],   // B
                pixels_[idx + 1],   // G  same
                pixels_[idx + 0]    // R
            };
            f.write((char*)bgr, 3);
        }
    }
}